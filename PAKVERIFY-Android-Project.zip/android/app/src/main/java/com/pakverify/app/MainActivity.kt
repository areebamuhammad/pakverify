package com.pakverify.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.pakverify.app.ui.SplashScreen
import com.pakverify.app.ui.WebViewScreen
import com.pakverify.app.ui.theme.PAKVERIFYTheme
import com.pakverify.app.ui.theme.PakDarkSurface

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            PAKVERIFYTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = PakDarkSurface
                ) {
                    AppNavigation(
                        onExitApp = { finish() }
                    )
                }
            }
        }
    }
}

@Composable
fun AppNavigation(
    onExitApp: () -> Unit
) {
    var isSplashFinished by remember { mutableStateOf(false) }

    Crossfade(
        targetState = isSplashFinished,
        animationSpec = tween(durationMillis = 600),
        label = "AppScreenTransition"
    ) { finished ->
        if (!finished) {
            SplashScreen(
                onSplashFinished = { isSplashFinished = true }
            )
        } else {
            WebViewScreen(
                onExitApp = onExitApp
            )
        }
    }
}